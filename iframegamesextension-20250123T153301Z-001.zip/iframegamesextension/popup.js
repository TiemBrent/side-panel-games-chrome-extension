document.getElementById('game1').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://g.igroutka.ru/games/575/MH1eBti4GNYLrUzk/3c697003-1e9f-4949-893b-a4c578257ef2/index.html';
});

document.getElementById('game2').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://www.kodub.com/apps/polytrack';
});

document.getElementById('game3').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://ubg365.github.io/drive-mad/play.html';
});

document.getElementById('game4').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://eclipseemu.me/play/';
});

document.getElementById('game5').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://freetoplayz.github.io/ragdoll-hit/';
});

document.getElementById('game6').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://stickman.pro/iframe/index.html';
});

document.getElementById('game7').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://szhong.4399.com/4399swf//upload_swf/ftp35/liuxinyu/20210324/jj01/index.html';
});

document.getElementById('game8').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://play.fancade.com/5BEC8352E4E078B1';
});

document.getElementById('game9').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://play.fancade.com/';
});

document.getElementById('game10').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://block-blast.io/game/block-blast/';
});

document.getElementById('game11').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://tunnelrushgame.io/game/tunnel-rush/';
});

document.getElementById('game12').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'http://slither.com/io';
});

document.getElementById('game13').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://paper-io.com/';
});

document.getElementById('game14').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://bitlifeonline.github.io/ragdoll-archers/';
});

document.getElementById('game15').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://sandspiel.club/';
});

document.getElementById('game16').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://turbowarp.org/322341152/embed';
});

document.getElementById('game17').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://html5.gamedistribution.com/rvvASMiM/5b0abd4c0faa4f5eb190a9a16d5a1b4c/index.html?gd_sdk_referrer_url=https%3A%2F%2Fwww.1001games.com%2Frace%2Fmoto-x3m&gd_zone_config=eyJwYXJlbnRVUkwiOiJodHRwczovL3d3dy4xMDAxZ2FtZXMuY29tL3JhY2UvbW90by14M20iLCJwYXJlbnREb21haW4iOiIxMDAxZ2FtZXMuY29tIiwidG9wRG9tYWluIjoiMTAwMWdhbWVzLmNvbSIsImhhc0ltcHJlc3Npb24iOmZhbHNlLCJsb2FkZXJFbmFibGVkIjp0cnVlLCJob3N0IjoiaHRtbDUuZ2FtZWRpc3RyaWJ1dGlvbi5jb20iLCJ2ZXJzaW9uIjoiMS41LjE3In0%253D';
});

document.getElementById('game18').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://g.igroutka.ru/games/793/2xTdm6GrXEuN0Kwq/fe831138-3321-40ed-b8cd-f1c482091e04/index.html';
});

document.getElementById('game19').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://play.wgplayground.com/game/897060ba3c1926e3d9e7cdfa080a4d2f/?r=wgplayground.com';
});

document.getElementById('game20').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://html5.gamedistribution.com/rvvASMiM/ac793d41fb5845e59afaad6292e141e1/index.html?gd_sdk_referrer_url=https%3A%2F%2Fwww.1001games.com%2Fsport%2Fpenalty-shooters-3&gd_zone_config=eyJwYXJlbnRVUkwiOiJodHRwczovL2h0bWw1LmdhbWVkaXN0cmlidXRpb24uY29tL2FjNzkzZDQxZmI1ODQ1ZTU5YWZhYWQ2MjkyZTE0MWUxLz9nZF9zZGtfcmVmZXJyZXJfdXJsPWh0dHBzOi8vd3d3LjEwMDFnYW1lcy5jb20vc3BvcnQvcGVuYWx0eS1zaG9vdGVycy0zIiwicGFyZW50RG9tYWluIjoiMTAwMWdhbWVzLmNvbSIsInRvcERvbWFpbiI6IjEwMDFnYW1lcy5jb20iLCJoYXNJbXByZXNzaW9uIjp0cnVlLCJsb2FkZXJFbmFibGVkIjp0cnVlLCJob3N0IjoiaHRtbDUuZ2FtZWRpc3RyaWJ1dGlvbi5jb20iLCJ2ZXJzaW9uIjoiMS41LjE3In0%253D';
});

document.getElementById('game21').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://www.1001games.com/lib/g/madalin-stunt-cars-2/v2/';
});

document.getElementById('game22').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://storage.y8.com/y8-studio/unity_webgl/bitlaslt/slope_v_1_2_5/?key=9757549&value=80527';
});

document.getElementById('game23').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://html5.gamedistribution.com/rvvASMiM/fd8ad948b534420caced19c62764019f/index.html?gd_sdk_referrer_url=https%3A%2F%2Fwww.y8.com%2Fgames%2Fcrazy_plane_landing&key=y8&value=default&gd_zone_config=eyJwYXJlbnRVUkwiOiJodHRwczovL2h0bWw1LmdhbWVkaXN0cmlidXRpb24uY29tL2ZkOGFkOTQ4YjUzNDQyMGNhY2VkMTljNjI3NjQwMTlmLz9nZF9zZGtfcmVmZXJyZXJfdXJsPWh0dHBzOi8vd3d3Lnk4LmNvbS9nYW1lcy9jcmF6eV9wbGFuZV9sYW5kaW5nJmtleT15OCZ2YWx1ZT1kZWZhdWx0IiwicGFyZW50RG9tYWluIjoieTguY29tIiwidG9wRG9tYWluIjoieTguY29tIiwiaGFzSW1wcmVzc2lvbiI6dHJ1ZSwibG9hZGVyRW5hYmxlZCI6dHJ1ZSwiaG9zdCI6Imh0bWw1LmdhbWVkaXN0cmlidXRpb24uY29tIiwidmVyc2lvbiI6IjEuNS4xNyJ9';
});

document.getElementById('game24').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://games.crazygames.com/en_US/space-waves/index.html?v=1.294';
});

document.getElementById('game25').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://geometrydashlitepc.io/game/geometry-dash-lite/';
});

document.getElementById('game26').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://storage.y8.com/y8-studio/unity_webgl/RHMInteractive/mtb-downhill-extreme/?key=y8&value=default';
});

document.getElementById('game27').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://storage.y8.com/y8-studio/html5/leaf/devil_s_gate/?key=y8&value=default';
});

document.getElementById('game28').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://bitlifesimulator.io/game/bitlife/';
});

document.getElementById('game29').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://wordly.org/';
});

document.getElementById('game30').addEventListener('click', function() {
    document.getElementById('gameFrame').src = 'https://diep.io/';
});

// Close UI functionality
document.getElementById('closeButton').addEventListener('click', function() {
    // Hide the button UI while keeping the iframe visible
    document.body.querySelectorAll('button').forEach(button => {
        button.style.display = 'none'; // Hides all buttons
    });
});
